name = input('What is your name? ')
print('Hi ' + name)
Trick = input('Do you want to see a trick? ')
print('Ok! Here I go! ')
birth_year = input('What is your birth Year? ')
age = 2021 - int(birth_year)
print('Alright, I guess that your age is....')
print(age)
print('Cool right?! Anyways lets go to the next question, ' + name)
fav_color = input('What is your favourite color? ')
print('Cool I LOVE ' + fav_color)
fav_food = input('What is your favourite food?? ')
print('Yummy!')
Fav_animal = input('What is your favourite animal? ')
print('I love ' + Fav_animal)
print('They are so cute! ')
Fav_place_travel = input('What is your favourite place you have traveled to? ')
print('Thats so interesting! ')
Game = input('Now lets play a game! What do you say? ')
print('Alright great! Ill give you three gueses to guess my secret number. Go ahead.')
secret_number = 9
guess_count = 0
guess_limit = 3
while guess_count < guess_limit:
    guess = int(input('Guess:'))
    guess_count +=1
    if guess == secret_number:
        print('Wow! You won! Good Job!')
        break
else:
    print('Sorry, you failed. The number was 9.')
print('Lets move to the next question. ')
Fav_place_travel2 = input('So, I know your favourite place you have traveled to already, what is a place you really want to travel to in the future?? ')
print('Wow one day I would love to go to ' + Fav_place_travel2)
print('For now, Ill just stay here and ask people questions! Bye! ')


